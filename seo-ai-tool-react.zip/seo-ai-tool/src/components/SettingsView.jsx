import React, { useState } from 'react'

export default function SettingsView({ apiKey, setApiKey }) {
  const [input, setInput] = useState(apiKey || '')
  const [saved, setSaved] = useState(false)
  const [error, setError] = useState('')

  function save() {
    if (!input.trim().startsWith('sk-ant')) {
      setError('API key không hợp lệ. Phải bắt đầu bằng sk-ant...')
      return
    }
    setError('')
    setApiKey(input.trim())
    localStorage.setItem('anthropic_api_key', input.trim())
    setSaved(true)
    setTimeout(() => setSaved(false), 2000)
  }

  function remove() {
    setInput('')
    setApiKey('')
    localStorage.removeItem('anthropic_api_key')
  }

  const inputStyle = {
    width: '100%', background: 'var(--bg-base)', border: '0.5px solid var(--border)',
    borderRadius: 6, color: 'var(--text-primary)', padding: '9px 12px',
    fontSize: 13, outline: 'none', fontFamily: 'DM Mono, monospace',
    transition: 'border-color 0.15s',
  }

  return (
    <div style={{ padding: 20, maxWidth: 600 }}>
      <div style={{ fontSize: 16, fontWeight: 600, color: 'var(--text-primary)', marginBottom: 20, letterSpacing: '-0.02em' }}>Cài đặt</div>

      <div style={{ background: 'var(--bg-surface)', border: '0.5px solid var(--border)', borderRadius: 8, padding: 20, marginBottom: 16 }}>
        <div style={{ fontSize: 15, fontWeight: 500, color: 'var(--text-primary)', marginBottom: 4 }}>Anthropic API Key</div>
        <div style={{ fontSize: 12, color: 'var(--text-muted)', marginBottom: 16 }}>
          Lấy miễn phí tại{' '}
          <a href="https://platform.anthropic.com" target="_blank" rel="noreferrer"
            style={{ color: 'var(--accent)', textDecoration: 'none' }}>
            platform.anthropic.com
          </a>
          {' '}— có $5 credit khi đăng ký mới
        </div>

        <div style={{ display: 'flex', gap: 10, marginBottom: 12 }}>
          <input
            type="password"
            value={input}
            onChange={e => setInput(e.target.value)}
            placeholder="sk-ant-api03-..."
            style={inputStyle}
            onFocus={e => e.target.style.borderColor = 'var(--accent)'}
            onBlur={e => e.target.style.borderColor = 'var(--border)'}
          />
          <button onClick={save} style={{
            background: 'var(--accent)', color: '#fff', border: 'none',
            borderRadius: 6, padding: '9px 16px', fontSize: 13,
            fontWeight: 500, cursor: 'pointer', whiteSpace: 'nowrap',
            transition: 'background 0.15s',
          }}
            onMouseEnter={e => e.currentTarget.style.background = 'var(--accent-hover)'}
            onMouseLeave={e => e.currentTarget.style.background = 'var(--accent)'}
          >
            Lưu key
          </button>
        </div>

        {error && <div style={{ color: 'var(--red)', fontSize: 12, marginBottom: 10, padding: '8px 12px', background: 'var(--red-dim)', borderRadius: 6 }}>{error}</div>}
        {saved && <div style={{ color: 'var(--green)', fontSize: 12, marginBottom: 10, padding: '8px 12px', background: 'var(--green-dim)', borderRadius: 6 }}>✓ Đã lưu thành công! API Key sẵn sàng sử dụng.</div>}

        {apiKey && (
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '10px 12px', background: 'var(--green-dim)', borderRadius: 6 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <span style={{ color: 'var(--green)', fontSize: 13 }}>✓</span>
              <span style={{ fontSize: 12, color: 'var(--green)' }}>API Key đang hoạt động</span>
              <span style={{ fontSize: 11, color: 'var(--text-muted)', fontFamily: 'DM Mono, monospace' }}>
                {apiKey.slice(0, 12)}...{apiKey.slice(-4)}
              </span>
            </div>
            <button onClick={remove} style={{ background: 'none', border: 'none', color: 'var(--text-muted)', fontSize: 11, cursor: 'pointer' }}>Xóa</button>
          </div>
        )}
      </div>

      <div style={{ background: 'var(--bg-surface)', border: '0.5px solid var(--border)', borderRadius: 8, padding: 20 }}>
        <div style={{ fontSize: 14, fontWeight: 500, color: 'var(--text-primary)', marginBottom: 14 }}>Hướng dẫn lấy API Key</div>
        {[
          ['1', 'Vào platform.anthropic.com và đăng ký tài khoản'],
          ['2', 'Xác minh email và hoàn thành đăng ký'],
          ['3', 'Vào mục "API Keys" ở menu bên trái'],
          ['4', 'Nhấn "Create Key" → đặt tên → Copy key'],
          ['5', 'Paste key vào ô phía trên và nhấn Lưu'],
        ].map(([num, text]) => (
          <div key={num} style={{ display: 'flex', gap: 12, marginBottom: 10, alignItems: 'flex-start' }}>
            <span style={{
              width: 22, height: 22, borderRadius: '50%',
              background: 'var(--accent-dim)', color: 'var(--accent)',
              fontSize: 11, fontWeight: 600, display: 'flex',
              alignItems: 'center', justifyContent: 'center', flexShrink: 0,
              fontFamily: 'DM Mono, monospace',
            }}>{num}</span>
            <span style={{ fontSize: 13, color: 'var(--text-secondary)', lineHeight: 1.6 }}>{text}</span>
          </div>
        ))}
        <div style={{ marginTop: 14, padding: '10px 12px', background: 'var(--amber-dim)', borderRadius: 6, fontSize: 12, color: 'var(--amber)' }}>
          💡 Tài khoản mới được tặng <strong>$5 credit miễn phí</strong> — đủ để tạo khoảng 500-1000 bài viết ngắn
        </div>
      </div>
    </div>
  )
}
