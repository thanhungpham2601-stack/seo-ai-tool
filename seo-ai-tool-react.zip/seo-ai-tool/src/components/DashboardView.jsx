import React from 'react'

const StatCard = ({ label, value, sub, color }) => (
  <div style={{
    background: 'var(--bg-surface)', border: '0.5px solid var(--border)',
    borderRadius: 8, padding: 16,
  }}>
    <div style={{ fontSize: 11, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.07em', marginBottom: 8 }}>{label}</div>
    <div style={{ fontSize: 24, fontWeight: 600, color: color || 'var(--text-primary)', fontFamily: 'DM Mono, monospace', letterSpacing: '-0.02em' }}>{value}</div>
    <div style={{ fontSize: 11, color: 'var(--text-muted)', marginTop: 4 }}>{sub}</div>
  </div>
)

const projects = [
  { name: 'Bảo hiểm', keywords: 497, articles: '0/185', pct: 5, status: 'wait' },
  { name: 'Du lịch', keywords: 200, articles: '12/80', pct: 15, status: 'processing' },
  { name: 'Sức khỏe', keywords: 350, articles: '45/140', pct: 32, status: 'done' },
]

export default function DashboardView() {
  return (
    <div style={{ padding: 20 }}>
      <div style={{ fontSize: 16, fontWeight: 600, color: 'var(--text-primary)', marginBottom: 20, letterSpacing: '-0.02em' }}>Tổng quan dự án</div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12, marginBottom: 24 }}>
        <StatCard label="Tổng từ khóa" value="1,047" sub="3 dự án đang chạy" color="var(--accent)" />
        <StatCard label="Cấu trúc hoàn thành" value="405" sub="38% tổng từ khóa" />
        <StatCard label="Bài viết đã tạo" value="57" sub="14% tổng bài" color="var(--green)" />
        <StatCard label="Credit còn lại" value="488k" sub="≈ $97.76 USD" color="var(--amber)" />
      </div>

      <div style={{ fontSize: 13, fontWeight: 500, color: 'var(--text-primary)', marginBottom: 12 }}>Tiến độ dự án</div>
      <div style={{ background: 'var(--bg-surface)', border: '0.5px solid var(--border)', borderRadius: 8, overflow: 'hidden' }}>
        <div style={{
          padding: '10px 16px', display: 'grid',
          gridTemplateColumns: '2fr 1fr 1fr 2fr 100px',
          gap: 8, borderBottom: '0.5px solid var(--border)',
          fontSize: 11, color: 'var(--text-muted)',
          textTransform: 'uppercase', letterSpacing: '0.07em',
        }}>
          <div>Dự án</div><div>Từ khóa</div><div>Bài viết</div><div>Tiến độ</div><div>Trạng thái</div>
        </div>
        {projects.map((p, i) => (
          <div key={i} style={{
            padding: '12px 16px', display: 'grid',
            gridTemplateColumns: '2fr 1fr 1fr 2fr 100px',
            gap: 8, borderBottom: i < projects.length - 1 ? '0.5px solid var(--border-light)' : 'none',
            alignItems: 'center', fontSize: 13,
          }}
            onMouseEnter={e => e.currentTarget.style.background = 'var(--bg-hover)'}
            onMouseLeave={e => e.currentTarget.style.background = 'transparent'}
          >
            <div style={{ color: 'var(--text-secondary)', fontWeight: 500 }}>{p.name}</div>
            <div style={{ color: 'var(--text-muted)', fontFamily: 'DM Mono, monospace', fontSize: 12 }}>{p.keywords}</div>
            <div style={{ color: 'var(--text-muted)', fontFamily: 'DM Mono, monospace', fontSize: 12 }}>{p.articles}</div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
              <div style={{ flex: 1, height: 4, background: 'var(--bg-elevated)', borderRadius: 2 }}>
                <div style={{ width: `${p.pct}%`, height: '100%', background: 'var(--accent)', borderRadius: 2, transition: 'width 0.5s ease' }} />
              </div>
              <span style={{ fontSize: 11, color: 'var(--text-muted)', fontFamily: 'DM Mono, monospace', minWidth: 28 }}>{p.pct}%</span>
            </div>
            <div>
              {p.status === 'processing' && <span style={{ background: 'var(--blue-dim)', color: 'var(--blue)', fontSize: 10, padding: '2px 8px', borderRadius: 4 }}>Đang viết</span>}
              {p.status === 'wait' && <span style={{ background: 'var(--bg-elevated)', color: 'var(--text-muted)', fontSize: 10, padding: '2px 8px', borderRadius: 4 }}>Đang nhập</span>}
              {p.status === 'done' && <span style={{ background: 'var(--green-dim)', color: 'var(--green)', fontSize: 10, padding: '2px 8px', borderRadius: 4 }}>Hoàn thành</span>}
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
