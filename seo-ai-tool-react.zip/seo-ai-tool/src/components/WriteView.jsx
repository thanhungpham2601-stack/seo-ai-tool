import React, { useState } from 'react'

const LoadingDots = () => (
  <div style={{ display: 'flex', gap: 4, alignItems: 'center' }}>
    {[0, 0.2, 0.4].map((delay, i) => (
      <div key={i} style={{
        width: 6, height: 6, borderRadius: '50%',
        background: 'var(--accent)',
        animation: `pulse 1.2s ease-in-out ${delay}s infinite`,
      }} />
    ))}
  </div>
)

export default function WriteView({ initialKeyword, apiKey }) {
  const [kwMain, setKwMain] = useState(initialKeyword || '')
  const [kwVariants, setKwVariants] = useState('')
  const [articleType, setArticleType] = useState('Đánh giá sản phẩm')
  const [articleLength, setArticleLength] = useState('~3,000 từ')
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState('')
  const [resultLabel, setResultLabel] = useState('')
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState('')

  const inputStyle = {
    width: '100%', background: 'var(--bg-base)', border: '0.5px solid var(--border)',
    borderRadius: 6, color: 'var(--text-primary)', padding: '9px 12px',
    fontSize: 13, outline: 'none', transition: 'border-color 0.15s',
  }
  const selectStyle = {
    ...inputStyle, cursor: 'pointer',
  }

  async function callClaude(prompt) {
    if (!apiKey) throw new Error('Chưa có API Key. Vui lòng vào tab Cài đặt để thêm key.')
    const res = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 4000,
        messages: [{ role: 'user', content: prompt }],
      }),
    })
    if (!res.ok) {
      const err = await res.json()
      throw new Error(err.error?.message || `API error ${res.status}`)
    }
    const data = await res.json()
    return data.content?.map(c => c.text || '').join('') || ''
  }

  async function generateArticle() {
    if (!kwMain.trim()) { setError('Vui lòng nhập từ khóa chính'); return }
    setError('')
    setLoading(true)
    setResult('')
    setResultLabel('Đang tạo bài viết SEO...')

    const prompt = `Bạn là chuyên gia SEO content writer người Việt Nam. Viết một bài viết SEO chuẩn hoàn chỉnh bằng tiếng Việt với:
- Từ khóa chính: "${kwMain}"
- Từ khóa phụ: ${kwVariants.trim() || 'không có'}
- Loại bài: ${articleType}
- Độ dài: ${articleLength}

Yêu cầu:
1. Tiêu đề H1 hấp dẫn chứa từ khóa chính
2. Meta description 150-160 ký tự
3. Mở đầu tự nhiên, cuốn hút (2-3 đoạn)
4. Cấu trúc H2, H3 rõ ràng, tối ưu SEO
5. Nội dung hữu ích, không spam từ khóa
6. Kết luận và CTA rõ ràng
7. Viết tự nhiên như người thật

Viết bài hoàn chỉnh ngay bây giờ.`

    try {
      const text = await callClaude(prompt)
      setResult(text)
      setResultLabel('Bài viết đã tạo xong ✓')
    } catch (e) {
      setResult('')
      setError(e.message)
      setResultLabel('')
    } finally {
      setLoading(false)
    }
  }

  async function analyzeKeywords() {
    if (!kwMain.trim()) { setError('Vui lòng nhập từ khóa chính'); return }
    setError('')
    setLoading(true)
    setResult('')
    setResultLabel('Đang phân tích cấu trúc từ khóa...')

    const prompt = `Phân tích cấu trúc SEO cho từ khóa sau (tiếng Việt, ngắn gọn, rõ ràng):

Từ khóa chính: "${kwMain}"
Từ khóa phụ: ${kwVariants.trim() || 'không có'}

Phân tích:
1. Search intent (mục đích tìm kiếm)
2. Đề xuất cấu trúc bài (H1, H2, H3)
3. Biến thể nên dùng trong bài
4. Độ khó SEO ước tính (thấp/trung bình/cao)
5. Lời khuyên tối ưu nhanh

Trình bày súc tích, có cấu trúc.`

    try {
      const text = await callClaude(prompt)
      setResult(text)
      setResultLabel('Phân tích hoàn tất ✓')
    } catch (e) {
      setResult('')
      setError(e.message)
      setResultLabel('')
    } finally {
      setLoading(false)
    }
  }

  function copyResult() {
    navigator.clipboard.writeText(result)
    setCopied(true)
    setTimeout(() => setCopied(false), 1500)
  }

  return (
    <div style={{ padding: 20, maxWidth: 800 }}>
      <div style={{ fontSize: 16, fontWeight: 600, color: 'var(--text-primary)', marginBottom: 20, letterSpacing: '-0.02em' }}>
        Viết bài với AI
      </div>

      {!apiKey && (
        <div style={{
          background: 'var(--amber-dim)', border: '0.5px solid var(--amber)',
          borderRadius: 8, padding: '12px 16px', marginBottom: 16,
          fontSize: 13, color: 'var(--amber)', display: 'flex', alignItems: 'center', gap: 8,
        }}>
          ⚠ Chưa có API Key — vào tab <strong>Cài đặt</strong> để thêm Anthropic API Key
        </div>
      )}

      <div style={{ background: 'var(--bg-surface)', border: '0.5px solid var(--border)', borderRadius: 8, padding: 20, marginBottom: 16 }}>
        <div style={{ fontSize: 15, fontWeight: 500, marginBottom: 16, color: 'var(--text-primary)' }}>Cấu hình bài viết</div>

        <label style={{ fontSize: 12, color: 'var(--text-muted)', display: 'block', marginBottom: 6 }}>Từ khóa chính *</label>
        <input
          value={kwMain}
          onChange={e => setKwMain(e.target.value)}
          placeholder="VD: bảo hiểm nhân thọ prudential"
          style={{ ...inputStyle, marginBottom: 14, borderColor: error && !kwMain ? 'var(--red)' : 'var(--border)' }}
          onFocus={e => e.target.style.borderColor = 'var(--accent)'}
          onBlur={e => e.target.style.borderColor = 'var(--border)'}
        />

        <label style={{ fontSize: 12, color: 'var(--text-muted)', display: 'block', marginBottom: 6 }}>Từ khóa phụ / biến thể (mỗi dòng một từ)</label>
        <textarea
          value={kwVariants}
          onChange={e => setKwVariants(e.target.value)}
          placeholder={'công ty bảo hiểm prudential\ntổng đài prudential\nbảo hiểm pru'}
          style={{ ...inputStyle, resize: 'vertical', minHeight: 100, marginBottom: 16 }}
          onFocus={e => e.target.style.borderColor = 'var(--accent)'}
          onBlur={e => e.target.style.borderColor = 'var(--border)'}
        />

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14, marginBottom: 18 }}>
          <div>
            <label style={{ fontSize: 12, color: 'var(--text-muted)', display: 'block', marginBottom: 6 }}>Loại bài viết</label>
            <select value={articleType} onChange={e => setArticleType(e.target.value)} style={selectStyle}
              onFocus={e => e.target.style.borderColor = 'var(--accent)'}
              onBlur={e => e.target.style.borderColor = 'var(--border)'}
            >
              {['Đánh giá sản phẩm', 'Thông tin / Hướng dẫn', 'So sánh', 'Danh sách', 'Pillar page'].map(o => <option key={o}>{o}</option>)}
            </select>
          </div>
          <div>
            <label style={{ fontSize: 12, color: 'var(--text-muted)', display: 'block', marginBottom: 6 }}>Độ dài bài</label>
            <select value={articleLength} onChange={e => setArticleLength(e.target.value)} style={selectStyle}
              onFocus={e => e.target.style.borderColor = 'var(--accent)'}
              onBlur={e => e.target.style.borderColor = 'var(--border)'}
            >
              {['~1,500 từ', '~2,000 từ', '~3,000 từ', '~4,000 từ'].map(o => <option key={o}>{o}</option>)}
            </select>
          </div>
        </div>

        {error && <div style={{ color: 'var(--red)', fontSize: 12, marginBottom: 12, padding: '8px 12px', background: 'var(--red-dim)', borderRadius: 6 }}>{error}</div>}

        <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap' }}>
          <button onClick={generateArticle} disabled={loading} style={{
            background: loading ? 'var(--accent-dim)' : 'var(--accent)',
            color: '#fff', border: 'none', borderRadius: 6,
            padding: '9px 18px', fontSize: 13, fontWeight: 500,
            cursor: loading ? 'not-allowed' : 'pointer', display: 'flex', alignItems: 'center', gap: 8,
            transition: 'background 0.15s',
          }}>
            {loading ? <><LoadingDots /> Đang tạo...</> : '✦ Tạo bài viết'}
          </button>
          <button onClick={analyzeKeywords} disabled={loading} style={{
            background: 'var(--bg-elevated)', border: '0.5px solid var(--border)',
            color: 'var(--text-secondary)', borderRadius: 6,
            padding: '9px 16px', fontSize: 13,
            cursor: loading ? 'not-allowed' : 'pointer',
          }}>
            Phân tích cấu trúc
          </button>
        </div>
      </div>

      {(result || (loading && resultLabel)) && (
        <div className="fade-in" style={{
          background: 'var(--bg-surface)', border: '0.5px solid var(--border)',
          borderRadius: 8, overflow: 'hidden',
        }}>
          <div style={{
            padding: '12px 16px', borderBottom: '0.5px solid var(--border)',
            display: 'flex', alignItems: 'center', justifyContent: 'space-between',
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
              <span style={{ fontSize: 13, fontWeight: 500, color: 'var(--text-primary)' }}>{resultLabel}</span>
              {loading && <LoadingDots />}
            </div>
            {result && !loading && (
              <button onClick={copyResult} style={{
                background: 'var(--bg-elevated)', border: '0.5px solid var(--border)',
                color: copied ? 'var(--green)' : 'var(--text-secondary)',
                fontSize: 11, padding: '4px 12px', borderRadius: 4, cursor: 'pointer',
              }}>
                {copied ? '✓ Đã sao chép' : 'Sao chép'}
              </button>
            )}
          </div>
          {result && (
            <div style={{
              padding: 16, fontSize: 13, lineHeight: 1.8,
              color: 'var(--text-secondary)', whiteSpace: 'pre-wrap',
              maxHeight: 500, overflowY: 'auto',
              fontFamily: 'DM Mono, monospace', fontSize: 12,
            }}>
              {result}
            </div>
          )}
        </div>
      )}
    </div>
  )
}
