import React, { useState } from 'react'

const Badge = ({ label, type }) => {
  const colors = {
    huong: { bg: '#1e2a3a', color: '#60a5fa' },
    pham: { bg: '#1a2e24', color: '#4ade80' },
    info: { bg: '#2a2410', color: '#fbbf24' },
    sanh: { bg: '#1e1a35', color: '#a78bfa' },
    sach: { bg: '#2a2410', color: '#fcd34d' },
    pillar: { bg: '#1e1a35', color: '#7c6af7' },
  }
  const c = colors[type] || { bg: '#1e2030', color: '#8b8fa8' }
  return (
    <span style={{ background: c.bg, color: c.color, fontSize: 10, padding: '2px 7px', borderRadius: 4, fontWeight: 500, whiteSpace: 'nowrap' }}>
      {label}
    </span>
  )
}

const StatusBadge = ({ status }) => {
  const s = status === 'processing'
    ? { bg: '#1e2a3a', color: '#60a5fa', label: 'Đang xử lý' }
    : { bg: '#1e2030', color: '#4a4e6a', label: 'Chờ xử lý' }
  return <span style={{ background: s.bg, color: s.color, fontSize: 10, padding: '2px 8px', borderRadius: 4, whiteSpace: 'nowrap' }}>{s.label}</span>
}

const VariantTag = ({ label }) => (
  <span style={{
    background: 'var(--bg-elevated)', border: '0.5px solid var(--border)',
    color: 'var(--text-muted)', fontSize: 11, padding: '2px 8px',
    borderRadius: 4, display: 'inline-flex', alignItems: 'center', gap: 4,
  }}>
    {label}
    <span style={{ cursor: 'pointer', color: 'var(--border)' }}>×</span>
  </span>
)

const KeywordRow = ({ kw, onWrite }) => (
  <>
    <div style={{
      padding: '9px 16px', display: 'flex', alignItems: 'center', gap: 10,
      borderBottom: '0.5px solid var(--border-light)',
    }}
      onMouseEnter={e => e.currentTarget.style.background = 'var(--bg-hover)'}
      onMouseLeave={e => e.currentTarget.style.background = 'transparent'}
    >
      <input type="checkbox" style={{ width: 13, height: 13, accentColor: 'var(--accent)', flexShrink: 0 }} />
      <span style={{ color: '#fbbf24', fontSize: 12, width: 14 }}>{kw.star ? '★' : ''}</span>
      <span
        onClick={() => onWrite(kw.name)}
        style={{
          flex: 1, color: kw.pillar ? 'var(--accent)' : 'var(--text-secondary)',
          fontWeight: kw.pillar ? 500 : 400, fontSize: 13, cursor: 'pointer',
          display: 'flex', alignItems: 'center', gap: 6, flexWrap: 'wrap',
        }}
      >
        {kw.name}
        {kw.pillar && <Badge label="PILLAR" type="pillar" />}
        {kw.type && <Badge label={kw.typeLabel} type={kw.type} />}
      </span>
      <span style={{ background: 'var(--bg-elevated)', color: 'var(--text-muted)', fontSize: 11, padding: '2px 6px', borderRadius: 3, whiteSpace: 'nowrap' }}>{kw.words}</span>
      <StatusBadge status={kw.status} />
      <div style={{ display: 'flex', gap: 4 }}>
        <button onClick={() => onWrite(kw.name)} style={{
          background: 'none', border: 'none', color: 'var(--text-muted)',
          fontSize: 12, padding: '2px 5px', borderRadius: 3, cursor: 'pointer',
        }}
          onMouseEnter={e => { e.currentTarget.style.color = 'var(--accent)'; e.currentTarget.style.background = 'var(--accent-dim)'; }}
          onMouseLeave={e => { e.currentTarget.style.color = 'var(--text-muted)'; e.currentTarget.style.background = 'none'; }}
          title="Viết bài">✏</button>
        <button style={{
          background: 'none', border: 'none', color: 'var(--text-muted)',
          fontSize: 12, padding: '2px 5px', borderRadius: 3, cursor: 'pointer',
        }}
          onMouseEnter={e => { e.currentTarget.style.color = 'var(--red)'; e.currentTarget.style.background = 'var(--red-dim)'; }}
          onMouseLeave={e => { e.currentTarget.style.color = 'var(--text-muted)'; e.currentTarget.style.background = 'none'; }}
        >✕</button>
      </div>
    </div>
    {kw.variants && (
      <div style={{ padding: '6px 16px 8px 50px', display: 'flex', gap: 6, flexWrap: 'wrap', borderBottom: '0.5px solid var(--border-light)' }}>
        {kw.variants.map((v, i) => <VariantTag key={i} label={v} />)}
      </div>
    )}
  </>
)

const groups = [
  {
    num: '#10', name: 'bảo hiểm nhân thọ prudential',
    pillar: 'bảo hiểm nhân thọ prudential',
    types: [{ label: 'Điều hướng', type: 'huong' }, { label: 'Sản phẩm', type: 'pham' }],
    words: '~3,000 từ', count: 10,
    keywords: [
      { name: 'bảo hiểm nhân thọ prudential', pillar: true, star: true, type: 'pham', typeLabel: 'Đánh giá', words: '~3,000 từ', status: 'wait', variants: ['công ty bảo hiểm prudential', 'công ty prudential', 'bảo hiểm pru', 'tổng đài bảo hiểm prudential', 'nop phi bao hiem pru'] },
      { name: 'gói bảo hiểm prudential 15 triệu', type: 'pham', typeLabel: 'Đánh giá', words: '~1,800 từ', status: 'wait' },
      { name: 'tổng đài prudential', words: '~1,500 từ', status: 'wait' },
    ]
  },
  {
    num: '#11', name: 'bảo hiểm nhân thọ daiichi',
    pillar: 'bảo hiểm nhân thọ daiichi',
    types: [{ label: 'Điều hướng', type: 'huong' }, { label: 'Sản phẩm', type: 'pham' }],
    words: '~3,000 từ', count: 12,
    keywords: [
      { name: 'bảo hiểm nhân thọ daiichi', pillar: true, star: true, type: 'pham', typeLabel: 'Đánh giá', words: '~3,000 từ', status: 'wait', variants: ['bảo hiểm daiichi', 'bảo hiểm daiichi life', 'daichilife', 'công ty bảo hiểm dai ichi'] },
      { name: 'các gói bảo hiểm dai ichi', type: 'sach', typeLabel: 'Danh sách', words: '~2,000 từ', status: 'wait' },
      { name: 'tổng đài daiichi', words: '~1,500 từ', status: 'wait' },
    ]
  },
  {
    num: '#12', name: 'công ty bảo hiểm nhân thọ',
    pillar: 'công ty bảo hiểm nhân thọ',
    types: [{ label: 'Thông tin', type: 'info' }, { label: 'So sánh', type: 'sanh' }],
    words: '~4,000 từ', count: 29,
    keywords: [
      { name: 'công ty bảo hiểm nhân thọ', pillar: true, star: true, type: 'sach', typeLabel: 'Danh sách', words: '~4,000 từ', status: 'wait', variants: ['các công ty bảo hiểm', 'top công ty bảo hiểm nhân thọ', 'bảo hiểm nhân thọ uy tín'] },
      { name: 'bảo hiểm nhân thọ chubb life', type: 'pham', typeLabel: 'Đánh giá', words: '~2,000 từ', status: 'wait' },
      { name: 'bảo hiểm nhân thọ sun life', type: 'pham', typeLabel: 'Đánh giá', words: '~2,000 từ', status: 'wait' },
      { name: 'bảo hiểm nhân thọ mb', type: 'pham', typeLabel: 'Đánh giá', words: '~2,000 từ', status: 'wait' },
    ]
  },
]

export default function KeywordsView({ onWrite }) {
  const [activeSubTab, setActiveSubTab] = useState(0)
  const subTabs = ['Tổng quan', 'Cấu trúc (185)', 'Bài viết (0/185)']

  return (
    <div style={{ padding: 20 }}>
      <div style={{ fontSize: 12, color: 'var(--text-muted)', marginBottom: 14, display: 'flex', alignItems: 'center', gap: 6 }}>
        ← Quay lại
        <span style={{ color: 'var(--text-primary)', fontWeight: 500 }}>Từ khóa Bảo hiểm (500)</span>
        <span style={{ background: 'var(--bg-elevated)', border: '0.5px solid var(--border)', color: 'var(--accent)', fontSize: 10, padding: '2px 7px', borderRadius: 4 }}>Nhập</span>
      </div>

      <div style={{ display: 'flex', gap: 20, fontSize: 12, color: 'var(--text-muted)', marginBottom: 16 }}>
        <span>Tổng: <strong style={{ color: 'var(--text-primary)' }}>497 keywords</strong></span>
        <span>Đã publish: <strong style={{ color: 'var(--text-primary)' }}>0</strong></span>
      </div>

      <div style={{ display: 'flex', borderBottom: '0.5px solid var(--border)', marginBottom: 16 }}>
        {subTabs.map((t, i) => (
          <button key={i} onClick={() => setActiveSubTab(i)} style={{
            padding: '8px 16px', background: 'none',
            border: 'none', borderBottom: `2px solid ${activeSubTab === i ? 'var(--accent)' : 'transparent'}`,
            color: activeSubTab === i ? 'var(--accent)' : 'var(--text-secondary)',
            fontSize: 13, cursor: 'pointer',
          }}>{t}</button>
        ))}
      </div>

      {groups.map((g, gi) => (
        <div key={gi} style={{
          background: 'var(--bg-surface)', border: '0.5px solid var(--border)',
          borderRadius: 8, marginBottom: 12, overflow: 'hidden',
        }}>
          <div style={{
            padding: '11px 16px', display: 'flex', alignItems: 'center',
            gap: 10, borderBottom: '0.5px solid var(--border-light)', flexWrap: 'wrap',
          }}>
            <span style={{ background: 'var(--bg-elevated)', color: 'var(--accent)', fontSize: 11, fontWeight: 500, padding: '2px 7px', borderRadius: 4, fontFamily: 'DM Mono, monospace' }}>{g.num}</span>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 13, fontWeight: 500, color: 'var(--text-secondary)' }}>{g.name}</div>
              <div style={{ fontSize: 11, color: 'var(--text-muted)' }}>Pillar: {g.pillar}</div>
            </div>
            {g.types.map((t, i) => <Badge key={i} label={t.label} type={t.type} />)}
            <span style={{ background: 'var(--bg-elevated)', color: 'var(--text-muted)', fontSize: 11, padding: '2px 6px', borderRadius: 3 }}>{g.words}</span>
            <span style={{ fontSize: 12, color: 'var(--text-muted)' }}><strong style={{ color: 'var(--text-primary)' }}>{g.count}</strong> keywords</span>
            <button style={{ background: 'var(--bg-elevated)', border: '0.5px solid var(--border)', color: 'var(--accent)', fontSize: 11, padding: '3px 10px', borderRadius: 4, cursor: 'pointer' }}>+ Thêm</button>
            <button style={{ background: 'var(--bg-hover)', border: '0.5px solid var(--border)', color: 'var(--text-secondary)', fontSize: 11, padding: '3px 10px', borderRadius: 4, cursor: 'pointer' }}>Chọn tất cả</button>
          </div>
          {g.keywords.map((kw, ki) => (
            <KeywordRow key={ki} kw={kw} onWrite={onWrite} />
          ))}
        </div>
      ))}
    </div>
  )
}
