import React from 'react'

const projects = [
  { name: 'Bảo hiểm (500)', color: '#7c6af7' },
  { name: 'Du lịch (200)', color: '#60a5fa' },
  { name: 'Sức khỏe (350)', color: '#4ade80' },
]

export default function Sidebar({ activeView, setActiveView }) {
  const navItems = [
    { id: 'keywords', label: 'Dự án', icon: <ListIcon /> },
    { id: 'write', label: 'Viết bài AI', icon: <PenIcon /> },
    { id: 'dashboard', label: 'Báo cáo', icon: <ChartIcon /> },
    { id: 'settings', label: 'Cài đặt', icon: <CogIcon /> },
  ]

  return (
    <aside style={{
      width: 210, background: 'var(--bg-surface)',
      borderRight: '0.5px solid var(--border)',
      display: 'flex', flexDirection: 'column',
      flexShrink: 0, height: '100%',
    }}>
      <div style={{
        padding: '18px 16px 14px',
        borderBottom: '0.5px solid var(--border)',
        display: 'flex', alignItems: 'center', gap: 10,
      }}>
        <div style={{
          width: 28, height: 28, borderRadius: 8,
          background: 'var(--accent)', display: 'flex',
          alignItems: 'center', justifyContent: 'center',
          fontSize: 13, fontWeight: 600, color: '#fff',
          fontFamily: 'DM Mono, monospace',
        }}>S</div>
        <span style={{ fontSize: 15, fontWeight: 600, color: 'var(--text-primary)', letterSpacing: '-0.02em' }}>SEO.AI</span>
      </div>

      <nav style={{ padding: '8px 0', flex: 1 }}>
        {navItems.map(item => (
          <button key={item.id} onClick={() => setActiveView(item.id)} style={{
            width: '100%', padding: '9px 14px',
            display: 'flex', alignItems: 'center', gap: 10,
            background: activeView === item.id ? 'var(--accent-dim)' : 'transparent',
            border: 'none', borderLeft: `3px solid ${activeView === item.id ? 'var(--accent)' : 'transparent'}`,
            color: activeView === item.id ? 'var(--accent)' : 'var(--text-secondary)',
            fontSize: 13, cursor: 'pointer', transition: 'all 0.15s',
            textAlign: 'left',
          }}
            onMouseEnter={e => { if (activeView !== item.id) { e.currentTarget.style.color = 'var(--text-primary)'; e.currentTarget.style.background = 'var(--bg-hover)'; } }}
            onMouseLeave={e => { if (activeView !== item.id) { e.currentTarget.style.color = 'var(--text-secondary)'; e.currentTarget.style.background = 'transparent'; } }}
          >
            {item.icon}
            {item.label}
          </button>
        ))}

        <div style={{ fontSize: 10, color: 'var(--text-muted)', padding: '14px 16px 6px', letterSpacing: '0.08em', textTransform: 'uppercase' }}>
          Dự án gần đây
        </div>
        {projects.map((p, i) => (
          <button key={i} onClick={() => setActiveView('keywords')} style={{
            width: '100%', padding: '7px 14px',
            display: 'flex', alignItems: 'center', gap: 9,
            background: 'transparent', border: 'none', borderLeft: '3px solid transparent',
            color: 'var(--text-secondary)', fontSize: 12, cursor: 'pointer',
          }}
            onMouseEnter={e => { e.currentTarget.style.color = 'var(--text-primary)'; e.currentTarget.style.background = 'var(--bg-hover)'; }}
            onMouseLeave={e => { e.currentTarget.style.color = 'var(--text-secondary)'; e.currentTarget.style.background = 'transparent'; }}
          >
            <div style={{ width: 6, height: 6, borderRadius: '50%', background: p.color, flexShrink: 0 }} />
            {p.name}
          </button>
        ))}
      </nav>

      <div style={{ padding: '12px 14px', borderTop: '0.5px solid var(--border)' }}>
        <div style={{ fontSize: 11, color: 'var(--text-muted)' }}>Credit còn lại</div>
        <div style={{ fontSize: 16, fontWeight: 600, color: 'var(--amber)', fontFamily: 'DM Mono, monospace' }}>488,784đ</div>
        <div style={{ fontSize: 10, color: 'var(--text-muted)' }}>≈ $97.76 USD</div>
      </div>
    </aside>
  )
}

function ListIcon() {
  return <svg width="14" height="14" viewBox="0 0 16 16" fill="currentColor"><path d="M2 4h12v1.5H2zm0 3h9v1.5H2zm0 3h6v1.5H2z"/></svg>
}
function PenIcon() {
  return <svg width="14" height="14" viewBox="0 0 16 16" fill="currentColor"><path d="M11 2l3 3-8 8H3v-3L11 2z"/></svg>
}
function ChartIcon() {
  return <svg width="14" height="14" viewBox="0 0 16 16" fill="currentColor"><rect x="1" y="1" width="6" height="6" rx="1"/><rect x="9" y="1" width="6" height="6" rx="1"/><rect x="1" y="9" width="6" height="6" rx="1"/><rect x="9" y="9" width="6" height="6" rx="1"/></svg>
}
function CogIcon() {
  return <svg width="14" height="14" viewBox="0 0 16 16" fill="currentColor"><path d="M8 5a3 3 0 100 6A3 3 0 008 5zM1.5 8a6.5 6.5 0 1113 0 6.5 6.5 0 01-13 0z"/></svg>
}
