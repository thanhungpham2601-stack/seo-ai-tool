import React, { useState, useEffect } from 'react'
import Sidebar from './components/Sidebar'
import KeywordsView from './components/KeywordsView'
import WriteView from './components/WriteView'
import DashboardView from './components/DashboardView'
import SettingsView from './components/SettingsView'

export default function App() {
  const [activeView, setActiveView] = useState('keywords')
  const [writeKeyword, setWriteKeyword] = useState('')
  const [apiKey, setApiKey] = useState(() => localStorage.getItem('anthropic_api_key') || '')

  function handleWrite(kw) {
    setWriteKeyword(kw)
    setActiveView('write')
  }

  const topbarTabs = [
    { id: 'keywords', label: 'Dự án' },
    { id: 'write', label: 'Viết bài', badge: 'AI' },
    { id: 'dashboard', label: 'Báo cáo' },
  ]

  return (
    <div style={{ display: 'flex', height: '100vh', overflow: 'hidden' }}>
      <Sidebar activeView={activeView} setActiveView={setActiveView} />

      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
        {/* Topbar */}
        <div style={{
          height: 48, background: 'var(--bg-surface)',
          borderBottom: '0.5px solid var(--border)',
          display: 'flex', alignItems: 'center',
          justifyContent: 'space-between',
          padding: '0 20px', flexShrink: 0,
        }}>
          <div style={{ display: 'flex' }}>
            {topbarTabs.map(t => (
              <button key={t.id} onClick={() => setActiveView(t.id)} style={{
                height: 48, padding: '0 16px',
                background: 'none', border: 'none',
                borderBottom: `2px solid ${activeView === t.id ? 'var(--accent)' : 'transparent'}`,
                color: activeView === t.id ? 'var(--accent)' : 'var(--text-secondary)',
                fontSize: 13, cursor: 'pointer',
                display: 'flex', alignItems: 'center', gap: 6,
                transition: 'color 0.15s',
              }}>
                {t.label}
                {t.badge && (
                  <span style={{
                    background: 'var(--accent)', color: '#fff',
                    fontSize: 10, padding: '1px 6px', borderRadius: 10,
                  }}>{t.badge}</span>
                )}
              </button>
            ))}
          </div>
          <button onClick={() => setActiveView('write')} style={{
            background: 'var(--accent)', color: '#fff',
            border: 'none', borderRadius: 6,
            padding: '7px 14px', fontSize: 13, fontWeight: 500,
            cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 6,
            transition: 'background 0.15s',
          }}
            onMouseEnter={e => e.currentTarget.style.background = 'var(--accent-hover)'}
            onMouseLeave={e => e.currentTarget.style.background = 'var(--accent)'}
          >
            + Tạo bài viết
          </button>
        </div>

        {/* Content */}
        <div style={{ flex: 1, overflowY: 'auto' }}>
          {activeView === 'keywords' && <KeywordsView onWrite={handleWrite} />}
          {activeView === 'write' && <WriteView initialKeyword={writeKeyword} apiKey={apiKey} />}
          {activeView === 'dashboard' && <DashboardView />}
          {activeView === 'settings' && <SettingsView apiKey={apiKey} setApiKey={setApiKey} />}
        </div>
      </div>
    </div>
  )
}
